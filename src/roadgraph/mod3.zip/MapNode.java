package roadgraph;

import geography.GeographicPoint;

public class MapNode implements Comparable<MapNode> {

	GeographicPoint loc;
	double distance;
	double preddistance;

	public MapNode(GeographicPoint loc) {
		this(loc, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
	}

	public MapNode(GeographicPoint loc, double distance) {
		this(loc, distance, Double.POSITIVE_INFINITY);
	}

	public MapNode(GeographicPoint loc, double distance, double preddistance) {
		this.loc = loc;
		this.distance = distance;
		this.preddistance = preddistance;
	}

	@Override
	public int compareTo(MapNode o) {
		// TODO Auto-generated method stub
		double distf1 = this.distance + this.preddistance;
		double distf2 = o.getDistance() + o.getPredDistance();
		if (distf1 > distf2) {
			return 1;
		} else if (distf1 < distf2) {
			return -1;
		}
		return 0;
	}

	public boolean equals(MapNode obj) {
		return loc.equals(obj.loc);
	}

	public GeographicPoint getLoc() {
		return loc;
	}

	public void setLoc(GeographicPoint loc) {
		this.loc = loc;
	}

	public double getDistance() {
		return distance;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}
	
	public double getPredDistance() {
		return preddistance;
	}

	public void setPredDistance(double preddistance) {
		this.preddistance = preddistance;
	}
	
	public double getFullDistance(){
		return (distance + preddistance);
	}

}
